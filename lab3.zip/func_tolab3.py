x1_min = 10
x1_max = 60
x2_min = -25
x2_max = 10
x3_min = 10
x3_max = 15
y_min = 200 + int((x1_min + x2_min + x3_min) / 3)
y_max = 200 + int((x1_max + x2_max + x3_max) / 3)
m = 3
N = 4
p = 0.95

def genermat():
    from random import randrange
    matrix_with_y = [[randrange(y_min, y_max) for y in range(3)] for x in range(4)]
    return matrix_with_y


def aver_y(lst):
    average = []
    for k in range(len(lst)):
        average.append(sum(lst[k]) / len(lst[k]))
    return average


def aver_x(lst):
    average = [0, 0, 0]
    for k in range(4):
        average[0] += lst[k][0] / 4
        average[1] += lst[k][1] / 4
        average[2] += lst[k][2] / 4
    return average


def det(a):
    from numpy.linalg import det
    return det(a)


class Critical:
    @staticmethod
    def get_cohren_value(size_of_selections, qty_of_selections, significance):
        from _pydecimal import Decimal
        from scipy.stats import f
        size_of_selections += 1
        partResult1 = significance / (size_of_selections - 1)
        params = [partResult1, qty_of_selections, (size_of_selections - 1 - 1) * qty_of_selections]
        fisher = f.isf(*params)
        result = fisher / (fisher + (size_of_selections - 1 - 1))
        return Decimal(result).quantize(Decimal('.0001')).__float__()

    @staticmethod
    def get_student_value(f3, significance):
        from _pydecimal import Decimal
        from scipy.stats import t
        return Decimal(abs(t.ppf(significance / 2, f3))).quantize(Decimal('.0001')).__float__()

    @staticmethod
    def get_fisher_value(f3, f4, significance):
        from _pydecimal import Decimal
        from scipy.stats import f
        return Decimal(abs(f.isf(significance, f4, f3))).quantize(Decimal('.0001')).__float__()
